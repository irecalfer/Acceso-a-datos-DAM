-- CREAMOS LA TABLA PARA LAS MATRICULAS

CREATE TABLE matriculaAlumnos(
    dni VARCHAR(9),
    nombre_modulo VARCHAR(60),
    curso VARCHAR(5),
    nota DOUBLE
);

-- INSERTAMOS ALGUNAS MATRICULAS DE ALUMNOS
INSERT INTO matriculaAlumnos VALUES('15872698P', 'FOL', '21-22', 8);
INSERT INTO matriculaAlumnos VALUES('15872698P', 'SGE', '21-22', 5.2);
INSERT INTO matriculaAlumnos VALUES('15872698P', 'Acceso a Datos', '18-19', 7);
INSERT INTO matriculaAlumnos VALUES('45963258L', 'EIE', '20-21', 6.3);
INSERT INTO matriculaAlumnos VALUES('58423692K', 'Bases de Datos', '21-22', 7.8);
INSERT INTO matriculaAlumnos VALUES('45963258L', 'Desarrollo de interfaces', '20-21', 6.5);