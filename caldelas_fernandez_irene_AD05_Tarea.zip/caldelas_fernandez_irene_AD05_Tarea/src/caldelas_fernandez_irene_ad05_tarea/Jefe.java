/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caldelas_fernandez_irene_ad05_tarea;

/**
 *
 * @author irene
 */
public class Jefe {

    private String nombre;
    private int antiguedad;
    private int edad;
    private Hijo hijo;

    public Jefe(String nombre, int antiguedad, int edad, Hijo hijo) {
        this.nombre = nombre;
        this.antiguedad = antiguedad;
        this.edad = edad;
        this.hijo = hijo;
    }
    
    public Jefe(String nombre, int edad){
        this.nombre = nombre;
        this.edad = edad; 
    }
    
    public Jefe(){
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Hijo getHijo() {
        return hijo;
    }

    public void setHijo(Hijo hijo) {
        this.hijo = hijo;
    }

    @Override
    //comportamiento del método toString heredado de la superclase Objet
    //Devuelve los atributos de un objeto Jefe
    public String toString() {
        return "Nombre:" +this.nombre + " " + "Antiguedad: "+ 
                this.antiguedad + " " +"Edad:"+ " "+ this.edad + " Hijo:" + this.hijo;

    }
}
