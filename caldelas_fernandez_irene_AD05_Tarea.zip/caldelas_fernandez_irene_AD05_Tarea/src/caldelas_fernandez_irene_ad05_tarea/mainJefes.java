/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caldelas_fernandez_irene_ad05_tarea;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;
import java.io.File;

/**
 *
 * @author irene
 */
public class mainJefes {

    public static void main(String[] args) {
        File fichero = new File("baseDatos");
        fichero.delete();
        /*Este código anterior lo ponemos por si la base de datos ya existiera y quisiéramos empezar desde el principio.*/
        //Va abrir la ruta de base de datos que le enviemos, si no existe la creara.
        ObjectContainer baseDatos = Db4oEmbedded.openFile("BDJefeHijo ");
        try {
            almacenaJefesHijos(baseDatos);
            System.out.println("JEFES Ccon MÁS de 55 AÑOS:");
            visualizaJefeMasEdad(baseDatos,53);
            System.out.println("MODIFICACION de la EDAD de MIGUEL:");
            actualizaEdadJefe(baseDatos, "Miguel", 46);
            consultaJefeConcreto(baseDatos, "Miguel");
            System.out.println("ELIMINACIÓN de los jefes que llevan MÁS de 6 AÑOS en la empresa:");
            borraJefes(baseDatos, 6);
            System.out.println("VISUALIZACIÓN de jefes e hijos restantes:");
            mostrarJefesHijosRestantes(baseDatos);
        } finally {
            baseDatos.close(); //cerrar la conexión a la base de datos
        }

    }

    //Método para almacenar datos en la Base de Objetos.
    public static void almacenaJefesHijos(ObjectContainer baseDatos) {
        //Persistir Objetos: almacenamos los objetos con el método store() y 
        //dentro de ellos ya inicializamos los objetos Jefe e Hijo.
        baseDatos.store(new Jefe("Ángel", 5, 53, new Hijo("Gustavo", 7)));
        baseDatos.store(new Jefe("Nieves", 3, 45, new Hijo("Iván", 3)));
        baseDatos.store(new Jefe("Jesús", 3, 5, new Hijo("Noelia", 3)));
        baseDatos.store(new Jefe("Dolores", 5, 63, new Hijo("Sergio", 7)));
        baseDatos.store(new Jefe("Vicki", 3, 5, null));
        baseDatos.store(new Jefe("Fátima", 5, 63, new Hijo("Lidia", 27)));
        baseDatos.store(new Jefe("Juan Luís", 3, 5, null));
        baseDatos.store(new Jefe("Elena", 1, 42, new Hijo("David", 19)));
        baseDatos.store(new Jefe("Miguel", 20, 45, new Hijo("Paula", 3)));
        baseDatos.store(new Jefe("Jesús", 19, 44, new Hijo("Rubén", 12)));
    }

    //Método para mostrar las consultas
    public static void mostrarConsulta(ObjectSet resul) {
        //mensaje indicando el total de objetos recuperados
        System.out.println("Recuperados " + resul.size() + " Objetos");
        while (resul.hasNext()) {//bucle que obtiene objeto a objeto
            System.out.println(resul.next());
        }
    }


    //Método que filtra los jefes que tienen más de 55 años
    public static void visualizaJefeMasEdad(ObjectContainer baseDatos, int edad){
        Query query = baseDatos.query(); //declaracion de un objeto query
        query.constrain(Jefe.class); // establece la clase a la que se aplica la restriccion
        query.descend("edad").constrain(edad).greater(); //establece la restriccion de busqueda
        ObjectSet result = query.execute();  //ejecuta consulta
        mostrarConsulta(result); //método que muestra los objetos recuperados
    }

    //Actualización de la edad de nombre nom a edad age
    public static void actualizaEdadJefe(ObjectContainer baseDatos, String name, int age) {
        //consulta jefe de patrón jefe(nombre,0). Consulta QBE
        ObjectSet result = baseDatos.queryByExample(new Jefe(name, 0));
        Jefe jefe = (Jefe) result.next(); //Obtenemos el jefe consultado
        jefe.setEdad(age); //asigna la nueva edad
        baseDatos.store(jefe); //almacena el jefe con la edad modificada    
    }

    //Consulta de un jefe concreto a través de su nombre
    public static void consultaJefeConcreto(ObjectContainer baseDatos, String nombre) {
        Query query = baseDatos.query(); //declaramos un objeto query
        query.constrain(Jefe.class); // establece la clase a la que se aplicará la restricción
        query.descend("nombre").constrain(nombre); //establece la restricción de búsqueda
        ObjectSet resul = query.execute(); //ejecutamos la consulta
        mostrarConsulta(resul);
    }
    
    //Método que borrará de la lista los jefes que llevan más de 6 años en la empresa
    public static void borraJefes(ObjectContainer baseDatos, int antiguedad){
        Query query = baseDatos.query(); //declaracion de un objeto query
        query.constrain(Jefe.class); //establece la clase a la que se aplicará las restricción
        query.descend("antiguedad").constrain(antiguedad).greater(); //establece la restricción de búsqueda
        ObjectSet result = query.execute(); //ejecuta consulta con resitrcción 
        while(result.hasNext()){ //bucle que recupera los objetos jefe y elimina de la Base de datos de objetos
            Jefe jefe = (Jefe) result.next();
            System.out.println("Eliminando:" + jefe);
            baseDatos.delete(jefe);
        }
        
    }
    
    //Consulta de todos los objetos jefe
    public static void mostrarJefesHijosRestantes(ObjectContainer baseDatos){
        //Se crea un objeto por defecto de jefe
        Jefe jefe = new Jefe();
        //consulta de los jefes
        ObjectSet res = baseDatos.queryByExample(jefe);
        mostrarConsulta(res);
    }
}
