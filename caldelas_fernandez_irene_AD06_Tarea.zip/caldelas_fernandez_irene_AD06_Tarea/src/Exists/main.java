/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exists;

import static Exists.main.conexion;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQResultSequence;

import net.xqj.exist.*;

/**
 *
 * @author Irene Caldelas Fernández
 */
public class main {

    public static XQConnection conexion() {
        XQConnection conexion = null;

        try {

            XQDataSource recurso = new ExistXQDataSource();
            recurso.setProperty("serverName", "localhost");
            recurso.setProperty("port", "8080");

            //creamos la conexión.
            conexion = recurso.getConnection();
        } catch (XQException e) {
            e.printStackTrace();
        }
        return conexion;
    }

    public static void main(String args[]) throws Exception {
        XQConnection conexion = conexion();

        String query = "for $variable in collection(/tarea6)//libro\n"
                + "return $variable/titulo";

        try {
            XQExpression xqe = conexion.createExpression();
            XQResultSequence resultado = xqe.executeQuery(query);

            while (resultado.next()) {
                System.out.println(resultado.getItemAsString(null));
            }
        } catch (XQException e) {
            System.out.println("Error:" + e);
        }
    }
}
