/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apartado1;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author irene
 */
public class GestionaFicheros {
    //Creamos un metodo abra en modo escritura el fichero
    //En caso de que no se pueda escribir mandara un mensaje de error
    public static RandomAccessFile creaFichero() {
        RandomAccessFile ficheroEmpleados = null;
        try {
            ficheroEmpleados = new RandomAccessFile("empleados.dat", "rw");
        } catch (Exception e) {
            System.out.println(("No se pudo escribir en el fichero") + e.getMessage());
        }
        return ficheroEmpleados;
    }

    public static void escribeEnFichero(RandomAccessFile f, List<Empleados> lista) throws IOException {

        //Vamos al final del fichero
        f.seek(f.length());
        //Introducimos los datos al final del fichero y con la propiedad de 
        //line.separator hacemos un salto de linea al final de cada empleado
        for (Empleados e : lista) {
            f.writeBytes(e.toString());
            f.writeBytes(System.getProperty("line.separator"));

        }
        //Cerramos el fichero
        f.close();

    }

    //Lo primero que haremos serÃ¡ la creaccion del fichero de acceso aleatorio
    public static void main(String[] args) {
        Empleados empleado1 = new Empleados(0001, "Luis Santos", "Calle San Juan de la Cruz", 
                1200, 25.6f);
        Empleados empleado2 = new Empleados(0002, "Maria Gomez", "Calle Mayor 4", 
                1140, 20.6f);
        Empleados empleado3 = new Empleados(0003, "Natalia Fernandez", "Av. del Progreso 7", 
                970, 13.4f);
        Empleados empleado4 = new Empleados(0004, "Carlos Gil", "Av. del ParaÃ­so 7", 
                1578, 31.6f);
        Empleados empleado5 = new Empleados(0005, "Manuel Gonzalez", "Calle Alejandro el magno 40 1F", 
                1400, 37.6f);
        List<Empleados> listaEmp = Arrays.asList(empleado1, empleado2, empleado3, empleado4, empleado5);

        RandomAccessFile fichero = creaFichero();
        try {
            escribeEnFichero(fichero, listaEmp);
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }

    }

}
