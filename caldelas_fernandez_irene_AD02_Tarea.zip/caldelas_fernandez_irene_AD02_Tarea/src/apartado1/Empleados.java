package apartado1;



/**
 *
 * @author Irene Caldelas FernÃ¡ndez
 */
public class Empleados {

    private int codigo;
    private String nombre;
    private String direccion;
    private float salario;
    private float comision;

    //Vamos a crear un objeto que contenga los datos de cada empleado
    public Empleados(int codigo, String nombre, String direccion, float salario,
            float comision) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.direccion = direccion;
        this.salario = salario;
        this.comision = comision;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setdireccion(String direccion) {
        this.direccion = direccion;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getComision() {
        return comision;
    }

    public void setComision(float comision) {
        this.comision = comision;
    }

    @Override
    public String toString() {
        return new StringBuilder().append(codigo).append(",").append(nombre).append(",").append(direccion).append(",").append(salario).append(",").append(comision).toString();
    }

}
