
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apartado1;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 *
 * @author irene
 */
public class ApartadoDOM {
    
    private static void CrearElemento (String dato, String valor, Element raiz,
            Document document){
        Element e = document.createElement(dato); //creamos el hijo
        Text text = document.createTextNode(valor); //le damos el valor
        raiz.appendChild(e); // pegamos el elemento hijo a la raiz
        e.appendChild(text); //pegamos el valor
    }

    public static void main(String[] args) throws IOException{
        //Utilizaremos el fichero que hemos creado en el apartado anterior, lo
        //abrimos en modo lectura
        File fichero = new File("empleados.dat");
        RandomAccessFile file = new RandomAccessFile(fichero, "r");
        
        //creamos una variable parqa situarnos al rpincipio del fichero y otra
        //donde guardaremos el codigo de empleado
        int codigo, posicion= 0;
        
        //Creamos dos Strings donde almacenaremos el nombre y la direccion
        //de los empleados
        String nombre, direccion;

        //Por ultimo para completar todos los datos tendremos dos variables para
        //almacenar el salario y la comision
        Double salario, comision;

        
        //Creamos una instancia DocumentBuilderFactory para construit el parser
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        
        try{
            DocumentBuilder builder = factory.newDocumentBuilder();
            //Creamos un documento vacio de nombre document con el nmdo raiz de
            //nombre Empleados y asignamos la version del XML, la interfaz
            //DOMImplementation permite creer objetos Document con nodo raiz
            DOMImplementation implementation = builder.getDOMImplementation();
            Document document = implementation.createDocument(null,"Empleados", null);
            document.setXmlVersion("1.0");
            file.seek(posicion); //Vamos al principio del fichero
            String linea;
            
            //Se saldrÃ¡ del bucle si ya no encuentra una linea que leer
            while((linea = file.readLine()) != null){
                //linea = file.readLine(); //Obtenemos empleado completo
                //Guardaremos en un array cada uno de los datos del empleado
                //utilizaremos la coma para partir los datos
                String[] dato = linea.split("\\,", -1);
                codigo = Integer.valueOf(dato[0]);
                nombre = dato[1];
                direccion = dato[2];
                salario = Double.valueOf(dato[3]);
                comision = Double.valueOf(dato[4]);
               
                if(codigo >0) { //Siempre que el codigo sea mayor que 0 se
                    //creara un empleado
                    Element raiz = document.createElement("empleado");
                    document.getDocumentElement().appendChild(raiz);
                    
                    //AÃ±adimos el codigo del empleado
                    CrearElemento("codigo", Integer.toString(codigo), raiz, document);
                    //AÃ±adimos el nombre del empleado
                    CrearElemento("nombre", nombre, raiz, document);
                    //AÃ±adimos la direccion del empleado
                    CrearElemento("direccion",direccion, raiz, document);
                    //AÃ±adimos el salario
                    CrearElemento("salario", Double.toString(salario) , raiz, document);
                    //AÃ±adimos la comision
                    CrearElemento("comision", Double.toString(comision), raiz, document);  
                }

            } //Finalizamos de recorrer el fichero
            
            Source source = new DOMSource(document);
            StreamResult r = new StreamResult(new java.io.File("Empleados.xml"));
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, r);

            }catch (Exception e) {
                System.err.println("Error" + e);
            }
           
        file.close(); // Cerramos el fichero
        } // fin del main
}   // fin de la clase
