package apartado2;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author irene
 */
public class DOMLee {

    public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new File("Libros.xml"));

            //Ontenemos la lista de nodos que tiene la etiqueta "libro"
            NodeList listaLibros = document.getElementsByTagName("libro");

            //Recorremos la lista
            for (int i = 0; i < listaLibros.getLength(); i++) {
                Node libro = listaLibros.item(i); //obtenemos de la lista cada libro
                System.out.println("Datos Libro");
                System.out.println("-----------");

                //Vemos el aÃ±o en el que fue publicado el libro
                if (libro.hasAttributes()) {
                    System.out.println(libro.getAttributes().getNamedItem("aÃ±o"));
                }

                //A continuacion vamos a extraer los datos que contiene ese libro
                NodeList datosLibro = libro.getChildNodes();

                //Recorremos la lista de los datod que contiene ese libro
                for (int j = 0; j < datosLibro.getLength(); j++) {
                    //obtenemos  de la lista cada dato
                    Node dato = datosLibro.item(j);
                    //Obtenemos de ese dato la lista de sus hijos titulo, autor...
                    NodeList subDatos = dato.getChildNodes();
                    

                    //Comprobamos que se trata de un dato de tipo Element
                    if (dato.getNodeType() == Node.ELEMENT_NODE) {
                        

                        if(dato.getNodeName().equals("autor")){
                            System.out.println(dato.getNodeName() + "=");
                            for(int k = 0; k <subDatos.getLength(); k++){
                                //Sacamos de la lista de nodos de autor que tiene
                                //hijos cada uno de los datos. 
                                Node subDatosContenido = subDatos.item(k);
                                
                                //Creamos una lista para sacar el valor del
                                //nombre y apellido de cada autor
                                NodeList datosAutor = subDatosContenido.getChildNodes();
                                for(int l = 0; l <datosAutor.getLength(); l++){
                                    Node apellidoContent = datosAutor.item(l);
                                    System.out.print(subDatosContenido.getNodeName() + "=");
                                    System.out.println(apellidoContent.getNodeValue());
                                }  
                           }
                        }else{ 
                        //Mostramos el nombre de la eqtiqueta que encuentra
                        System.out.print(dato.getNodeName() + "=");
                        //Sacamos de ese nodo el valor  
                        Node contenido = dato.getFirstChild();
                        //Mostramos el valor
                        System.out.println(contenido.getNodeValue());
                        }
                    }

                }
                System.out.println();
            }
        } catch (IOException ex) {
            System.out.println("ERROR: Se ha producido un error el leer el fichero\n" + ex.getMessage());
        } catch (ParserConfigurationException ex) {
            System.out.println("ERROR: No se ha podido crear el generador de documentos XML\n" + ex.getMessage());

        }
    }
}
