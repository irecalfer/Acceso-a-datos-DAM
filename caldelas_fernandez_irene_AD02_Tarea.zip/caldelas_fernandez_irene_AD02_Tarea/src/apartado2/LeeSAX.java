/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apartado2;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author irene
 */
public class LeeSAX {

    private static class GestionContenido extends DefaultHandler {

        public GestionContenido() {
            super();
        }

        public void startDocument() {
            System.out.println("Comienzo de los libros");
        }

        public void endDocument() {
            System.out.println("Final de los libros");
        }

        public void startElement(String url, String nombre, String nombreC,
                Attributes atts) {
            //vemos si la etiqueta libro es la que se obtiene y de ser asi
            //imprimimos el atributo que tiene
            if (nombreC.equalsIgnoreCase("libro")) {
                System.out.println("Etiqueta:" + nombre + " " + "aÃ±o" + atts.getValue("aÃ±o"));
            } else {
                System.out.printf("Etiqueta: %s %n", nombre);

            }

        }

        public void endElement(String url, String nombre, String nombreC) {
            System.out.printf("Fin Etiqueta: %s %n", nombre);
            if (nombre.equalsIgnoreCase("libro")) {
                //hacemos un salto de linea para ver mejor cada libro
                System.out.printf("\n");
            }
        }

        public void characters(char[] ch, int inicio, int longitud) {
            String car = new String(ch, inicio, longitud);
            //si el dato va a estar vacio hacemos que directamente no lo imprima
            //en caso de contener un valor lo imprimira
            if (!car.isEmpty()) {
                System.out.printf("Dato: %s %n", car);
            }
        }

    }

    public static void main(String[] args) throws SAXException, IOException, FileNotFoundException {
        //Creamos un objeto procesador de XML
        XMLReader procesadorXML = XMLReaderFactory.createXMLReader();
        //Para indicar al procesador XML los objetos que realizaran el tratamiento
        //utilizaremos el siguiente metodos incluidos dentro de los objetos
        //XMLReader: setContentHandler()
        GestionContenido gestor = new GestionContenido();
        procesadorXML.setContentHandler(gestor);

        //Definimos el fichero XML que se va a leer mediante un objeto InputSource
        InputSource fileXML = new InputSource("Libros.xml");

        //Procesamos el documento XML mediante el metodo parse()
        procesadorXML.parse(fileXML);
    }

}
